package com.project.rest;

public class FireRestCtrl {

}
